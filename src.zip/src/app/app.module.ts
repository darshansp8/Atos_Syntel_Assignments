import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { MyCmpComponent } from './my-cmp/my-cmp.component';
import { BindingComponent } from './binding/binding.component';
import { DirectivesComponent } from './directives/directives.component';
import { ChangeTextDirective } from './change-text.directive';
import { PipingComponent } from './piping/piping.component';

@NgModule({
  declarations: [
    AppComponent,
    MyCmpComponent,
    BindingComponent,
    DirectivesComponent,
    ChangeTextDirective,
    PipingComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

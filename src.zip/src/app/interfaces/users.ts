export interface Users{
    id: number;
    name: string;
    username: string;
    phone: number;
}
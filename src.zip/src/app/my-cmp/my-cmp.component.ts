import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-cmp',
  templateUrl: './my-cmp.component.html',
  styleUrls: ['./my-cmp.component.css']
})
export class MyCmpComponent implements OnInit {
  name = "World";
  list = ["Programmer", "Developer", "Designer", "Tester"];
  constructor() { }

  ngOnInit(): void {
  }

}

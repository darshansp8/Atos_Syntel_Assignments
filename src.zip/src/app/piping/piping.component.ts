import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-piping',
  templateUrl: './piping.component.html',
  styleUrls: ['./piping.component.css']
})
export class PipingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  name = "John Doe";
  location = "California";
  income = 452333.23;
  expense = 245874.4532
  dob = new Date("May 23, 1970");
}
